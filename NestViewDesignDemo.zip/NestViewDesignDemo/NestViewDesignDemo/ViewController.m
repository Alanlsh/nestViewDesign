//
//  ViewController.m
//  NestViewDesignDemo
//
//  Created by Alan on 2019/5/23.
//  Copyright © 2019 Alan. All rights reserved.
//

#import "ViewController.h"
#import "FirstViewController.h"
#import "SecondViewController.h"
#import "ThirdViewController.h"
@interface ViewController ()<UIScrollViewDelegate>

@property (nonatomic, strong) FirstViewController *firstViewController;

@property (nonatomic, strong) SecondViewController *secondViewController;

@property (nonatomic, strong) ThirdViewController *thirdViewController;


@property (nonatomic, strong) UIImageView *imageView;

@property (nonatomic, strong) UILabel *label;

@property (nonatomic, strong) UIScrollView *scrollView;

///标记当前可控制的tableView，用于区别对待于滚动中设置另两个tableView的偏移量
@property (nonatomic, strong) UITableView *currentTableView;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    [self.view addSubview:self.scrollView];
    [self.view addSubview:self.imageView];
    
    //观察者模式 观察tableView的偏移量
    [self.firstViewController.tableView addObserver:self forKeyPath:@"contentOffset" options:(NSKeyValueObservingOptionNew) context:nil];
    [self.secondViewController.tableView addObserver:self forKeyPath:@"contentOffset" options:(NSKeyValueObservingOptionNew) context:nil];
    [self.thirdViewController.tableView addObserver:self forKeyPath:@"contentOffset" options:(NSKeyValueObservingOptionNew) context:nil];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context
{
    if (object == self.currentTableView) {
        
        CGPoint offset = [[change valueForKey:NSKeyValueChangeNewKey] CGPointValue];
        
        ///只有imageView需要移动的时候才需要关心另外两个tableView
        if (0 <= offset.y && offset.y <= 160) {
            CGRect rect = self.imageView.frame;
            rect.origin.y = self.label.frame.size.height + 160 - offset.y - self.imageView.bounds.size.height;
            self.imageView.frame = rect;
            [self resetTableViewOffset:offset];
            
        }else if (offset.y < 0){
            CGRect rect = self.imageView.frame;
            if (rect.origin.y != 0) {
                rect.origin.y = 0;
                self.imageView.frame = rect;
                [self resetTableViewOffset:CGPointMake(0, 0)];
            }
        }else if (offset.y > 160){
            CGRect rect = self.imageView.frame;
            if (rect.origin.y != 40 - self.imageView.bounds.size.height) {
                rect.origin.y = 40 - self.imageView.bounds.size.height;
                self.imageView.frame = rect;
                [self resetTableViewOffset:CGPointMake(0, 160)];
            }
        }
    }
}

- (void)resetTableViewOffset:(CGPoint)offset
{
    if (self.currentTableView == self.firstViewController.tableView) {
        
        self.secondViewController.tableView.contentOffset = offset;
        self.thirdViewController.tableView.contentOffset = offset;
    }else if (self.currentTableView == self.secondViewController.tableView) {
        
        self.firstViewController.tableView.contentOffset = offset;
        self.thirdViewController.tableView.contentOffset = offset;
    }else if (self.currentTableView == self.thirdViewController.tableView) {
        
        self.firstViewController.tableView.contentOffset = offset;
        self.secondViewController.tableView.contentOffset = offset;
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat contentOffsetX = scrollView.contentOffset.x;
    
    if (contentOffsetX < self.view.bounds.size.width/2) {
        self.currentTableView = self.firstViewController.tableView;
    }else if (contentOffsetX < self.view.bounds.size.width * 3/2){
        self.currentTableView = self.secondViewController.tableView;
    }else if (contentOffsetX < self.view.bounds.size.width * 5/2){
        self.currentTableView = self.thirdViewController.tableView;
    }
}

#pragma mark - initializing
- (UIScrollView *)scrollView
{
    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 40, self.view.bounds.size.width, self.view.bounds.size.height - 40)];
        _scrollView.contentSize = CGSizeMake(self.view.bounds.size.width * 3, self.view.bounds.size.height - 40);
        _scrollView.pagingEnabled = YES;
        _scrollView.delegate = self;
        
        UIView *view1 = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 160)];
        self.firstViewController.tableView.tableHeaderView = view1;
        self.firstViewController.tableView.frame = CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height - 40);
        [_scrollView addSubview:self.firstViewController.tableView];
        
        UIView *view2 = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 160)];
        self.secondViewController.tableView.tableHeaderView = view2;
        self.secondViewController.tableView.frame = CGRectMake(self.view.bounds.size.width, 0, self.view.bounds.size.width, self.view.bounds.size.height - 40);
        [_scrollView addSubview:self.secondViewController.tableView];
        
        UIView *view3 = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 160)];
        self.thirdViewController.tableView.tableHeaderView = view3;
        self.thirdViewController.tableView.frame = CGRectMake(self.view.bounds.size.width * 2, 0, self.view.bounds.size.width, self.view.bounds.size.height - 40);
        [_scrollView addSubview:self.thirdViewController.tableView];
        
        ///默认第一个tableView
        self.currentTableView = self.firstViewController.tableView;
  
    }
    return _scrollView;
}

- (UIImageView *)imageView
{
    if (!_imageView) {
        _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 200)];
        _imageView.image = [UIImage imageNamed:@"1"];
        
        [_imageView addSubview:self.label];
        CGRect rect = self.label.frame;
        rect.origin.y = 200 - 40;
        self.label.frame = rect;
    }
    return _imageView;
}

- (UILabel *)label
{
    if (!_label) {
        _label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 40)];
        _label.text = @"测试栏";
        _label.textColor = [UIColor redColor];
        _label.textAlignment = NSTextAlignmentCenter;
        _label.backgroundColor = [UIColor whiteColor];
    }
    return _label;
}

- (FirstViewController *)firstViewController
{
    if (!_firstViewController) {
        _firstViewController = [[FirstViewController alloc] init];
    }
    return _firstViewController;
}

- (SecondViewController *)secondViewController
{
    if (!_secondViewController) {
        _secondViewController = [[SecondViewController alloc] init];
    }
    return _secondViewController;
}

- (ThirdViewController *)thirdViewController
{
    if (!_thirdViewController) {
        _thirdViewController = [[ThirdViewController alloc] init];
    }
    return _thirdViewController;
}


@end
